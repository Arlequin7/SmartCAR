Overview

The SmartCAR ROS2 project provides a fully autonomous robotic vehicle capable of navigation and environmental interaction. This project uses ROS2 and simulation tools like Gazebo and RViz to develop and visualize the SmartCAR model in both simulated and real-world environments. It includes key functionalities such as spawning the robot in a simulated world, visualizing its model and transforms in RViz, and publishing odometry data.
Table of Contents

    Installation
    Usage
    Project Structure
    Function Documentation
    Troubleshooting
    License

Installation
Dependencies

    ROS2 Humble
    Gazebo and RViz2 (for simulation and visualization)
    Additional dependencies specified in package.xml

Installation Steps

    Clone the Repository:

    bash

git clone https://github.com/username/smartcar_ros2.git
cd smartcar_ros2

Build the Workspace:

bash

colcon build

Source the Workspace:

bash

    source install/setup.bash

Usage

To launch the SmartCAR in Gazebo and visualize it in RViz, run the following command:

bash

ros2 launch smart_car smartcar.launch.py

This will:

    Start the Gazebo simulator with the specified world file.
    Spawn the SmartCAR model in the Gazebo environment.
    Publish the robot's URDF description and transformations.
    Launch RViz with the specified configuration.
    Start the odometry publisher node to provide real-time wheel odometry data.

Launch Files

    smartcar.launch.py: Main launch file that initiates Gazebo, RViz, and the necessary nodes for simulation.

Project Structure

bash

ros2_ws/
├── install/              # Built packages and install dependencies
├── build/                # Compiled files generated during the build process
├── log/                  # Log files for debugging and issue tracking
└── src/                  # Source files and packages
    ├── smart_car/        # Core package for the SmartCAR project
    │   ├── config/       # Configuration files (e.g., localization, navigation parameters)
    │   ├── launch/       # Launch files to initialize the project components
    │   ├── rviz/         # RViz configurations for visualizing the SmartCAR
    │   ├── urdf/         # URDF and XACRO files defining the robot model
    │   ├── world/        # Gazebo world files for simulation environments
    │   └── script/       # Additional scripts, including the odometry publisher
    └── smartcar_msgs/    # Custom message definitions and dependencies for SmartCAR

Function Documentation
generate_launch_description()

The main function in smartcar.launch.py responsible for setting up the SmartCAR's launch environment.

Components:

    start_gazebo: Initializes Gazebo with the specified world file.
        world_path: Path to the Gazebo world file (e.g., smalltown.world).
    spawn_robot: Spawns the SmartCAR model in the Gazebo simulation.
        urdf_path: Path to the SmartCAR URDF file for defining its physical model.
    robot_state_publisher: Publishes the robot’s description and transformations.
        robot_description: Loads the URDF using xacro.
    rviz_node: Launches RViz to visualize the SmartCAR.
        rviz configuration file: Configures the visualization (e.g., smart_car.rviz).
    odometry_publisher: Publishes wheel odometry for tracking the robot’s movements.

Dependencies:

    os, launch, launch_ros, and ament_index_python libraries for defining launch descriptions and fetching package directories.

Troubleshooting

    Model Not Appearing in Gazebo/RViz: Verify the paths to the URDF and RViz configuration files in the launch file. Ensure all dependencies are correctly sourced.
    Path Errors: Double-check that all file paths in smartcar.launch.py are correct, especially if any files have been moved or renamed.
    RViz Display Issues: Make sure RViz is correctly configured to subscribe to the necessary topics and that the RViz configuration file is properly set up
