// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SMARTCAR_MSGS__MSG__STATUS_HPP_
#define SMARTCAR_MSGS__MSG__STATUS_HPP_

#include "smartcar_msgs/msg/detail/status__struct.hpp"
#include "smartcar_msgs/msg/detail/status__builder.hpp"
#include "smartcar_msgs/msg/detail/status__traits.hpp"

#endif  // SMARTCAR_MSGS__MSG__STATUS_HPP_
